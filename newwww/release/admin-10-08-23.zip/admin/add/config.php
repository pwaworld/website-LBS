<?php

$dbHost = 'localhost';
$dbUser = 'littleb1_lbsadmin';
$dbPass = 'yScoo#]F]=}F';
$dbName = 'littleb1_newlbs';

?>